## Getting Started with makeflaskreact

I wanted to make a commmand line tool to easily generate a flask app that will work with React's cors issues
because I have to rebuild this a lot.

To run `$ pip install makeflaskreact`
then  `$ makeflaskreact`
optionally you could add a `FOLDER_NAME` and `API_PATH` name in that order.
the default folder name will be `server` and the default api path will be `/api/`



