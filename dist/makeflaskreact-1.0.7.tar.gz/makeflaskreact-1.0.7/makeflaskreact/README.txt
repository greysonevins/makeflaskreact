###New Flask App for React

#### Getting Started

`flask run --port %s --host %s`
